import React, { useState, useEffect, useRef } from 'react';
import {
  Plus,
  Search,
  MapPin,
  Download,
  Wifi,
  WifiOff,
  Eye,
  EyeOff,
  Trash2,
  RefreshCw
} from 'lucide-react';

// ============================================================================
// SERVICIOS DE BD Y SINCRONIZACIÓN
// ============================================================================

const DB_NAME = 'EmergencyDB';
const DB_VERSION = 1;
const STORE_NAME = 'registros';

// Inicializar IndexedDB
const initDB = () => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);

    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id', autoIncrement: true });
        store.createIndex('nombre', 'nombre', { unique: false });
        store.createIndex('estado', 'estado', { unique: false });
        store.createIndex('timestamp', 'timestamp', { unique: false });
        store.createIndex('sincronizado', 'sincronizado', { unique: false });
      }
    };
  });
};

// Agregar registro a la BD local
const addRegistro = async (registro) => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const nuevoRegistro = {
      ...registro,
      id: `${Date.now()}-${Math.random()}`,
      timestamp: new Date().toISOString(),
      sincronizado: false
    };
    const request = store.add(nuevoRegistro);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(nuevoRegistro);
  });
};

// Obtener todos los registros
const getAllRegistros = async () => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.getAll();
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result.reverse());
  });
};

// Eliminar registro
const deleteRegistro = async (id) => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.delete(id);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
};

// Obtener geolocalización
const getGeolocation = () => {
  return new Promise((resolve, reject) => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
            accuracy: position.coords.accuracy
          });
        },
        (error) => reject(error),
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    } else {
      reject(new Error('Geolocalización no disponible'));
    }
  });
};

// Detectar estado de red
const checkNetworkStatus = () => {
  return navigator.onLine;
};

// Exportar a CSV
const exportToCSV = (registros) => {
  const headers = ['ID', 'Nombre', 'Edad', 'Estado', 'Ubicación', 'Notas', 'Hora Registro'];
  const rows = registros.map(r => [
    r.id,
    r.nombre,
    r.edad,
    r.estado,
    r.ubicacion || 'Sin ubicación',
    r.notas || '',
    new Date(r.timestamp).toLocaleString('es-ES')
  ]);

  const csv = [
    headers.join(','),
    ...rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
  ].join('\n');

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `registro_emergencia_${new Date().toISOString().split('T')[0]}.csv`;
  link.click();
};

// Exportar a JSON
const exportToJSON = (registros) => {
  const json = JSON.stringify(registros, null, 2);
  const blob = new Blob([json], { type: 'application/json;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `registro_emergencia_${new Date().toISOString().split('T')[0]}.json`;
  link.click();
};

// Simular sincronización con servidor (para implementación real)
const syncToServer = async (registros) => {
  // Aquí iría la lógica real de sincronización con el servidor
  // return fetch('/api/sync', { method: 'POST', body: JSON.stringify(registros) });
  return Promise.resolve();
};

// ============================================================================
// COMPONENTE PRINCIPAL
// ============================================================================

export default function EmergencyApp() {
  const [registros, setRegistros] = useState([]);
  const [isOnline, setIsOnline] = useState(checkNetworkStatus());
  const [activeTab, setActiveTab] = useState('registro'); // 'registro' o 'datos'
  const [searchTerm, setSearchTerm] = useState('');
  const [filterEstado, setFilterEstado] = useState('');
  const [showNotification, setShowNotification] = useState('');
  const [isLoadingGeo, setIsLoadingGeo] = useState(false);
  const [showForm, setShowForm] = useState(false);

  // Estado del formulario
  const [formData, setFormData] = useState({
    nombre: '',
    edad: '',
    estado: 'Verde',
    ubicacion: '',
    notas: '',
    lat: null,
    lng: null
  });

  // Cargar registros al iniciar
  useEffect(() => {
    loadRegistros();
  }, []);

  // Escuchar cambios de conexión
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setShowNotification('🟢 Conectado - Sincronizando datos...');
      setTimeout(() => setShowNotification(''), 3000);
    };

    const handleOffline = () => {
      setIsOnline(false);
      setShowNotification('🔴 Sin conexión - Trabajando en modo offline');
      setTimeout(() => setShowNotification(''), 3000);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const loadRegistros = async () => {
    try {
      const data = await getAllRegistros();
      setRegistros(data);
    } catch (error) {
      console.error('Error cargando registros:', error);
      setShowNotification('⚠️ Error cargando datos');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleGetGeolocation = async () => {
    setIsLoadingGeo(true);
    try {
      const geo = await getGeolocation();
      setFormData(prev => ({
        ...prev,
        lat: geo.lat.toFixed(6),
        lng: geo.lng.toFixed(6),
        ubicacion: `${geo.lat.toFixed(6)}, ${geo.lng.toFixed(6)}`
      }));
      setShowNotification('✅ Ubicación capturada');
      setTimeout(() => setShowNotification(''), 2000);
    } catch (error) {
      setShowNotification('❌ No se pudo capturar ubicación');
      setTimeout(() => setShowNotification(''), 2000);
    } finally {
      setIsLoadingGeo(false);
    }
  };

  const handleSubmitRegistro = async (e) => {
    e.preventDefault();
    if (!formData.nombre.trim()) {
      setShowNotification('⚠️ El nombre es obligatorio');
      return;
    }

    try {
      const nuevoRegistro = await addRegistro(formData);
      setRegistros(prev => [nuevoRegistro, ...prev]);
      setFormData({
        nombre: '',
        edad: '',
        estado: 'Verde',
        ubicacion: '',
        notas: '',
        lat: null,
        lng: null
      });
      setShowNotification('✅ Registro guardado correctamente');
      setShowForm(false);
      setTimeout(() => setShowNotification(''), 2000);
    } catch (error) {
      console.error('Error guardando registro:', error);
      setShowNotification('❌ Error al guardar');
      setTimeout(() => setShowNotification(''), 2000);
    }
  };

  const handleDeleteRegistro = async (id) => {
    if (window.confirm('¿Confirma eliminar este registro?')) {
      try {
        await deleteRegistro(id);
        setRegistros(prev => prev.filter(r => r.id !== id));
        setShowNotification('🗑️ Registro eliminado');
        setTimeout(() => setShowNotification(''), 2000);
      } catch (error) {
        console.error('Error eliminando registro:', error);
      }
    }
  };

  // Filtrar registros
  const registrosFiltrados = registros.filter(r => {
    const matchNombre = r.nombre.toLowerCase().includes(searchTerm.toLowerCase());
    const matchEstado = !filterEstado || r.estado === filterEstado;
    return matchNombre && matchEstado;
  });

  // Estadísticas
  const stats = {
    total: registros.length,
    verde: registros.filter(r => r.estado === 'Verde').length,
    amarillo: registros.filter(r => r.estado === 'Amarillo').length,
    rojo: registros.filter(r => r.estado === 'Rojo').length,
    desaparecido: registros.filter(r => r.estado === 'Desaparecido').length
  };

  const getEstadoColor = (estado) => {
    switch (estado) {
      case 'Verde':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'Amarillo':
        return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'Rojo':
        return 'bg-red-100 text-red-800 border-red-300';
      case 'Desaparecido':
        return 'bg-purple-100 text-purple-800 border-purple-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-slate-900 border-b-2 border-red-600 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-red-600 p-2 rounded-lg">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">EMERGENCIAS</h1>
              <p className="text-xs text-slate-300">Sistema de Registro en Tiempo Real</p>
            </div>
          </div>

          {/* Estado de conexión */}
          <div className="flex items-center gap-2">
            {isOnline ? (
              <div className="flex items-center gap-1 bg-green-900 px-3 py-1 rounded-full">
                <Wifi className="w-4 h-4 text-green-400 animate-pulse" />
                <span className="text-xs font-semibold text-green-400">ONLINE</span>
              </div>
            ) : (
              <div className="flex items-center gap-1 bg-red-900 px-3 py-1 rounded-full">
                <WifiOff className="w-4 h-4 text-red-400 animate-pulse" />
                <span className="text-xs font-semibold text-red-400">OFFLINE</span>
              </div>
            )}
          </div>
        </div>

        {/* Pestañas */}
        <div className="flex bg-slate-800 border-t border-slate-700">
          <button
            onClick={() => setActiveTab('registro')}
            className={`flex-1 py-3 font-bold text-center transition-all ${
              activeTab === 'registro'
                ? 'bg-red-600 text-white border-b-4 border-red-400'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            ➕ NUEVO REGISTRO
          </button>
          <button
            onClick={() => setActiveTab('datos')}
            className={`flex-1 py-3 font-bold text-center transition-all ${
              activeTab === 'datos'
                ? 'bg-blue-600 text-white border-b-4 border-blue-400'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            📊 VER DATOS ({registros.length})
          </button>
        </div>
      </header>

      {/* Notificación */}
      {showNotification && (
        <div className="fixed top-20 left-4 right-4 bg-slate-800 border-l-4 border-red-500 text-white p-4 rounded-lg shadow-lg z-40 animate-pulse">
          {showNotification}
        </div>
      )}

      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* TAB: NUEVO REGISTRO */}
        {activeTab === 'registro' && (
          <div className="space-y-6">
            {/* Botón para mostrar formulario */}
            {!showForm && (
              <button
                onClick={() => setShowForm(true)}
                className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold py-4 px-6 rounded-xl flex items-center justify-center gap-3 text-lg shadow-lg transform hover:scale-105 transition-transform"
              >
                <Plus className="w-7 h-7" />
                REGISTRAR NUEVA PERSONA
              </button>
            )}

            {/* Formulario */}
            {showForm && (
              <div className="bg-slate-800 border-2 border-red-500 rounded-xl p-6 shadow-xl">
                <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                  <div className="bg-red-600 p-2 rounded">
                    <Plus className="w-6 h-6 text-white" />
                  </div>
                  Registro Rápido de Persona Afectada
                </h2>

                <form onSubmit={handleSubmitRegistro} className="space-y-4">
                  {/* Nombre */}
                  <div>
                    <label className="block text-white font-bold mb-2 text-sm">
                      NOMBRE COMPLETO *
                    </label>
                    <input
                      type="text"
                      name="nombre"
                      value={formData.nombre}
                      onChange={handleInputChange}
                      placeholder="Ej: Juan Pérez García"
                      className="w-full bg-slate-700 text-white placeholder-slate-400 border-2 border-slate-600 rounded-lg px-4 py-3 focus:outline-none focus:border-red-500 focus:ring-2 focus:ring-red-400 text-lg"
                      autoFocus
                    />
                  </div>

                  {/* Edad */}
                  <div>
                    <label className="block text-white font-bold mb-2 text-sm">
                      EDAD APROXIMADA
                    </label>
                    <input
                      type="number"
                      name="edad"
                      value={formData.edad}
                      onChange={handleInputChange}
                      placeholder="Ej: 35"
                      min="0"
                      max="120"
                      className="w-full bg-slate-700 text-white placeholder-slate-400 border-2 border-slate-600 rounded-lg px-4 py-3 focus:outline-none focus:border-red-500 focus:ring-2 focus:ring-red-400 text-lg"
                    />
                  </div>

                  {/* Estado */}
                  <div>
                    <label className="block text-white font-bold mb-2 text-sm">
                      ESTADO DE SALUD *
                    </label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {['Verde', 'Amarillo', 'Rojo', 'Desaparecido'].map(estado => (
                        <button
                          key={estado}
                          type="button"
                          onClick={() => setFormData(prev => ({ ...prev, estado }))}
                          className={`py-3 px-4 font-bold rounded-lg border-2 transition-all transform hover:scale-105 ${
                            formData.estado === estado
                              ? getEstadoColor(estado) + ' ring-2 ring-white'
                              : 'bg-slate-700 text-slate-300 border-slate-600 hover:border-slate-500'
                          }`}
                        >
                          {estado === 'Verde' && '✅ Sin daño'}
                          {estado === 'Amarillo' && '⚠️ Herido leve'}
                          {estado === 'Rojo' && '🚨 Crítico'}
                          {estado === 'Desaparecido' && '❓ Buscado'}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Ubicación */}
                  <div>
                    <label className="block text-white font-bold mb-2 text-sm">
                      UBICACIÓN ACTUAL
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        name="ubicacion"
                        value={formData.ubicacion}
                        onChange={handleInputChange}
                        placeholder="Dirección o GPS (lat, lng)"
                        className="flex-1 bg-slate-700 text-white placeholder-slate-400 border-2 border-slate-600 rounded-lg px-4 py-3 focus:outline-none focus:border-red-500 focus:ring-2 focus:ring-red-400"
                      />
                      <button
                        type="button"
                        onClick={handleGetGeolocation}
                        disabled={isLoadingGeo}
                        className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 text-white font-bold py-3 px-4 rounded-lg flex items-center gap-2 transition-all transform hover:scale-105"
                      >
                        {isLoadingGeo ? (
                          <RefreshCw className="w-5 h-5 animate-spin" />
                        ) : (
                          <MapPin className="w-5 h-5" />
                        )}
                      </button>
                    </div>
                    {formData.lat && formData.lng && (
                      <p className="text-xs text-green-400 mt-1">
                        📍 Ubicación capturada: {formData.lat}, {formData.lng}
                      </p>
                    )}
                  </div>

                  {/* Notas */}
                  <div>
                    <label className="block text-white font-bold mb-2 text-sm">
                      OBSERVACIONES / NOTAS
                    </label>
                    <textarea
                      name="notas"
                      value={formData.notas}
                      onChange={handleInputChange}
                      placeholder="Ej: Tiene lesión en brazo izquierdo, alergias a penicilina..."
                      rows="3"
                      className="w-full bg-slate-700 text-white placeholder-slate-400 border-2 border-slate-600 rounded-lg px-4 py-3 focus:outline-none focus:border-red-500 focus:ring-2 focus:ring-red-400"
                    />
                  </div>

                  {/* Botones */}
                  <div className="flex gap-3 pt-4">
                    <button
                      type="submit"
                      className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold py-4 px-6 rounded-lg flex items-center justify-center gap-2 transition-all transform hover:scale-105 text-lg"
                    >
                      ✅ GUARDAR REGISTRO
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowForm(false);
                        setFormData({
                          nombre: '',
                          edad: '',
                          estado: 'Verde',
                          ubicacion: '',
                          notas: '',
                          lat: null,
                          lng: null
                        });
                      }}
                      className="flex-1 bg-slate-700 hover:bg-slate-600 text-white font-bold py-4 px-6 rounded-lg transition-all"
                    >
                      ❌ CANCELAR
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        )}

        {/* TAB: VER DATOS */}
        {activeTab === 'datos' && (
          <div className="space-y-6">
            {/* Estadísticas */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="bg-gradient-to-br from-blue-900 to-blue-800 border-2 border-blue-500 rounded-lg p-4 text-center">
                <p className="text-3xl font-bold text-white">{stats.total}</p>
                <p className="text-blue-200 text-sm font-semibold">Total</p>
              </div>
              <div className="bg-gradient-to-br from-green-900 to-green-800 border-2 border-green-500 rounded-lg p-4 text-center">
                <p className="text-3xl font-bold text-white">{stats.verde}</p>
                <p className="text-green-200 text-sm font-semibold">Sin daño</p>
              </div>
              <div className="bg-gradient-to-br from-yellow-900 to-yellow-800 border-2 border-yellow-500 rounded-lg p-4 text-center">
                <p className="text-3xl font-bold text-white">{stats.amarillo}</p>
                <p className="text-yellow-200 text-sm font-semibold">Leve</p>
              </div>
              <div className="bg-gradient-to-br from-red-900 to-red-800 border-2 border-red-500 rounded-lg p-4 text-center">
                <p className="text-3xl font-bold text-white">{stats.rojo}</p>
                <p className="text-red-200 text-sm font-semibold">Crítico</p>
              </div>
              <div className="bg-gradient-to-br from-purple-900 to-purple-800 border-2 border-purple-500 rounded-lg p-4 text-center">
                <p className="text-3xl font-bold text-white">{stats.desaparecido}</p>
                <p className="text-purple-200 text-sm font-semibold">Buscado</p>
              </div>
            </div>

            {/* Búsqueda y Filtros */}
            <div className="bg-slate-800 border-2 border-slate-700 rounded-lg p-4 space-y-4">
              <div className="flex gap-3 flex-col md:flex-row">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Buscar por nombre..."
                    className="w-full bg-slate-700 text-white placeholder-slate-400 border-2 border-slate-600 rounded-lg px-4 py-2 pl-10 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-400"
                  />
                </div>

                <select
                  value={filterEstado}
                  onChange={(e) => setFilterEstado(e.target.value)}
                  className="bg-slate-700 text-white border-2 border-slate-600 rounded-lg px-4 py-2 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-400"
                >
                  <option value="">Todos los estados</option>
                  <option value="Verde">✅ Sin daño</option>
                  <option value="Amarillo">⚠️ Herido leve</option>
                  <option value="Rojo">🚨 Crítico</option>
                  <option value="Desaparecido">❓ Buscado</option>
                </select>
              </div>

              {/* Exportar */}
              <div className="flex gap-2">
                <button
                  onClick={() => exportToCSV(registrosFiltrados)}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-all transform hover:scale-105"
                >
                  <Download className="w-4 h-4" />
                  Descargar CSV
                </button>
                <button
                  onClick={() => exportToJSON(registrosFiltrados)}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-all transform hover:scale-105"
                >
                  <Download className="w-4 h-4" />
                  Descargar JSON
                </button>
              </div>
            </div>

            {/* Tabla de Registros */}
            {registrosFiltrados.length > 0 ? (
              <div className="space-y-4">
                {registrosFiltrados.map(registro => (
                  <div
                    key={registro.id}
                    className={`border-l-4 rounded-lg p-4 shadow-lg ${getEstadoColor(
                      registro.estado
                    )}`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="text-lg font-bold">{registro.nombre}</h3>
                          <span className="text-xs opacity-75">
                            ID: {registro.id.slice(0, 8)}
                          </span>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                          {registro.edad && (
                            <p className="opacity-90">
                              <span className="font-semibold">Edad:</span> {registro.edad} años
                            </p>
                          )}
                          <p className="opacity-90">
                            <span className="font-semibold">Estado:</span> {registro.estado}
                          </p>
                          {registro.ubicacion && (
                            <p className="opacity-90 flex items-center gap-1">
                              <MapPin className="w-4 h-4" />
                              <span className="font-semibold">Ubicación:</span> {registro.ubicacion}
                            </p>
                          )}
                          <p className="opacity-75 text-xs">
                            {new Date(registro.timestamp).toLocaleString('es-ES')}
                          </p>
                        </div>

                        {registro.notas && (
                          <p className="mt-3 p-2 bg-black bg-opacity-20 rounded text-sm">
                            <span className="font-semibold">Notas:</span> {registro.notas}
                          </p>
                        )}
                      </div>

                      <button
                        onClick={() => handleDeleteRegistro(registro.id)}
                        className="bg-red-600 hover:bg-red-700 text-white p-2 rounded-lg transition-all transform hover:scale-110"
                        title="Eliminar registro"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-slate-800 rounded-lg border-2 border-slate-700">
                <p className="text-slate-400 text-lg">
                  {searchTerm || filterEstado
                    ? '❌ No hay registros que coincidan con los criterios'
                    : '📋 Sin registros aún. ¡Comienza agregando uno!'}
                </p>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-12 bg-slate-900 border-t border-slate-700 py-4 text-center text-slate-400 text-xs">
        <p>🚨 Sistema de Emergencias v1.0 | Funciona con o sin conexión a internet</p>
      </footer>
    </div>
  );
}
