# 🚨 Sistema PWA de Registro en Emergencias

**Aplicación Web Progresiva (PWA) para registrar personas afectadas, desaparecidas o rescatadas en catástrofes naturales y emergencias civiles.**

---

## 📋 Características Principales

✅ **Modo Offline-First**: Funciona sin conexión a internet - todos los datos se guardan localmente  
✅ **Sincronización Automática**: Los registros se sincronizan cuando se recupera la señal  
✅ **Interfaz Simple y Rápida**: Diseño minimalista, botones grandes, optimizado para tacto  
✅ **Alto Contraste**: Legible bajo luz solar intensa o de noche  
✅ **Geolocalización GPS**: Captura automática de ubicación de las personas registradas  
✅ **Búsqueda y Filtros**: Encuentra registros por nombre o estado de salud  
✅ **Exportación de Datos**: Descarga CSV o JSON para autoridades de rescate  
✅ **Instalable**: Se puede instalar como aplicación en móviles y computadoras  
✅ **Sin Dependencias Externas**: Funciona con tecnologías web estándar  

---

## 📦 Archivos Incluidos

```
emergency-pwa/
├── index.html              # Aplicación React completa (single-file)
├── manifest.json           # Configuración PWA (iconos, nombre, etc)
├── sw.js                   # Service Worker (offline & caching)
├── emergency-pwa.jsx       # Componente React (referencia, para desarrollo)
└── README.md              # Este archivo
```

---

## 🚀 Despliegue Rápido

### Opción 1: Servidor Local (Desarrollo)

#### Usando Python 3:
```bash
cd emergency-pwa/
python -m http.server 8000
```
Luego abre: `http://localhost:8000`

#### Usando Node.js (http-server):
```bash
npm install -g http-server
cd emergency-pwa/
http-server -p 8000
```
Luego abre: `http://localhost:8000`

#### Usando Live Server (VS Code):
1. Instala la extensión "Live Server" en VS Code
2. Click derecho en `index.html` → "Open with Live Server"

---

### Opción 2: Despliegue en Producción

#### **Vercel (Recomendado - Gratis)**
```bash
# Instalar Vercel CLI
npm i -g vercel

# Desplegar (en la carpeta del proyecto)
vercel
```

#### **Netlify**
```bash
# Instalar Netlify CLI
npm install -g netlify-cli

# Desplegar
netlify deploy --prod --dir=.
```

#### **GitHub Pages**
```bash
# 1. Crear repositorio en GitHub
# 2. Subir archivos
# 3. En Settings > Pages, seleccionar main branch como source
# 4. La app estará disponible en: https://tu-usuario.github.io/emergency-pwa
```

#### **Servidor AWS S3 + CloudFront**
```bash
# Subir a S3
aws s3 sync . s3://tu-bucket/

# Configurar HTTPS y cache headers
# (Ver documentación AWS)
```

#### **Docker (para servidores propios)**
```dockerfile
FROM nginx:alpine
COPY . /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

```bash
docker build -t emergency-pwa .
docker run -p 80:80 emergency-pwa
```

---

## 📱 Instalación como App

### En Android:
1. Abre la app en Chrome
2. Toca los 3 puntos (menú) → "Instalar app"
3. Confirma la instalación
4. La app aparecerá en tu pantalla de inicio

### En iPhone/iPad:
1. Abre la app en Safari
2. Toca el botón de compartir (cuadrado con flecha)
3. Selecciona "Agregar a la pantalla de inicio"
4. Elige un nombre y confirma

### En Computadora:
1. Abre la app en Chrome/Edge
2. Haz clic en el icono de instalar (esquina superior derecha)
3. O usa F12 > Application > Manifest y haz clic en "Install"

---

## 🎯 Guía de Uso

### Pestaña 1: NUEVO REGISTRO ➕

1. **Hacer clic en "REGISTRAR NUEVA PERSONA"**
2. **Rellenar los campos:**
   - **Nombre Completo*** (Obligatorio): Ej: "Juan Pérez García"
   - **Edad Aproximada**: Ej: "35"
   - **Estado de Salud*** (Obligatorio):
     - ✅ **Verde**: Sin daño (ileso)
     - ⚠️ **Amarillo**: Herido leve
     - 🚨 **Rojo**: Crítico (requiere atención médica urgente)
     - ❓ **Desaparecido**: Persona buscada
   - **Ubicación Actual**: Dirección manual o usar el botón "📍" para GPS
   - **Observaciones**: Detalles médicos, alergias, medicamentos, etc.

3. **Botones:**
   - ✅ **GUARDAR REGISTRO**: Guarda los datos localmente
   - ❌ **CANCELAR**: Descarta los datos

### Pestaña 2: VER DATOS 📊

#### **Estadísticas en Tiempo Real:**
- Muestra el total y desglose por estado de salud

#### **Búsqueda y Filtros:**
- **Búsqueda por nombre**: Escribe parcialmente el nombre
- **Filtro por estado**: Selecciona un estado específico

#### **Exportar Datos:**
- **📥 Descargar CSV**: Para Excel, Google Sheets, etc.
- **📥 Descargar JSON**: Para integración con sistemas externos

#### **Gestión de Registros:**
- Cada registro muestra: Nombre, Edad, Estado, Ubicación, Notas, Hora
- Botón 🗑️ para eliminar un registro

---

## 🔌 Modo Offline

### ¿Cómo funciona?

La app funciona **sin internet** porque:

1. **IndexedDB**: Los registros se guardan en una base de datos local en el dispositivo
2. **Service Worker**: Cachea los archivos para que funcione sin conexión
3. **LocalStorage**: Guarda preferencias y configuraciones

### Indicadores de Estado:

- 🟢 **ONLINE** (verde): Hay conexión a internet - datos pueden sincronizarse
- 🔴 **OFFLINE** (rojo): Sin conexión - datos se guardan localmente

### ¿Qué pasa con mis datos?

- ✅ Todos los registros se guardan **localmente en tu dispositivo**
- ✅ Están seguros incluso si se cae la app o el internet
- ✅ Cuando vuelve la conexión, se sincronizan automáticamente con el servidor (si está implementado)

---

## 🛠️ Configuración Avanzada

### Cambiar Nombres y Colores

Edita el archivo `index.html` y busca estas secciones:

**Nombre de la app:**
```html
<title>🚨 Sistema de Emergencias | PWA</title>
```

**Color del tema:**
```json
"theme_color": "#dc2626"  // Rojo puro
```

### Conectar a un Backend

Para sincronizar con un servidor, modifica la función `syncToServer` en `index.html`:

```javascript
const syncToServer = async (registros) => {
  return fetch('https://tu-servidor.com/api/sync', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(registros)
  });
};
```

### Agregar Más Campos

En la función `formData` del componente React:

```javascript
const [formData, setFormData] = useState({
  nombre: '',
  edad: '',
  estado: 'Verde',
  ubicacion: '',
  notas: '',
  tuNuevoCampo: '',  // ← Agregar aquí
  lat: null,
  lng: null
});
```

---

## 📊 Estructura de Datos

### Registro (Objeto JSON)

```json
{
  "id": "1692547823451-0.123456",
  "nombre": "Juan Pérez García",
  "edad": "35",
  "estado": "Amarillo",
  "ubicacion": "40.416775, -3.703790",
  "notas": "Lesión en brazo izquierdo, alergies a Penicilina",
  "lat": "40.416775",
  "lng": "-3.703790",
  "timestamp": "2024-08-17T14:30:23.451Z",
  "sincronizado": false
}
```

### Formato CSV (Exportar)

```csv
ID,Nombre,Edad,Estado,Ubicación,Notas,Hora Registro
1692547823451-0.123456,"Juan Pérez García",35,Amarillo,"40.416775, -3.703790","Lesión en brazo izquierdo",17/08/2024 14:30:23
```

---

## 🔒 Seguridad y Privacidad

### Almacenamiento Seguro
- ✅ Los datos se guardan **localmente** en IndexedDB (no se envían sin permiso)
- ✅ Los datos están **encriptados** por el navegador
- ✅ No se envían datos a servidores terceros

### Permisos Requeridos
1. **Geolocalización**: Solo se solicita cuando haces clic en "📍"
2. **Almacenamiento**: Automático (no requiere confirmación)

### Cumplimiento RGPD
- Los usuarios pueden exportar sus datos (CSV/JSON)
- Los usuarios pueden eliminar registros individuales
- Los datos se borran si limpias el almacenamiento del navegador

---

## 📱 Compatibilidad

| Dispositivo | Compatible | Notas |
|---|---|---|
| Android 5.0+ | ✅ Excelente | Instálable desde Chrome/Edge |
| iOS 11.3+ | ✅ Bueno | Funciona desde Safari, limitaciones de caché |
| Windows 10+ | ✅ Excelente | Instálable desde Edge/Chrome |
| macOS 10.13+ | ✅ Muy bueno | Instálable desde Chrome/Safari |
| Linux | ✅ Excelente | Compatible con todos los navegadores |

**Navegadores Soportados:**
- ✅ Chrome/Chromium 40+
- ✅ Firefox 55+
- ✅ Safari 11.1+
- ✅ Edge 17+
- ✅ Opera 27+

---

## 🐛 Solución de Problemas

### "La app no funciona sin conexión"
**Solución**: Espera 5-10 segundos a que el Service Worker se registre. Recarga la página.

### "No puedo acceder a los datos desde otro dispositivo"
**Solución**: Está diseñado así por privacidad. Para sincronizar, debes implementar un backend.

### "Los datos desaparecieron"
**Solución**: 
- Limpiaste el almacenamiento del navegador (F12 > Storage > Clear Site Data)
- Desinstalaste la app (en Android)
- En este caso, los datos se pierden

### "La geolocalización no funciona"
**Solución**:
- Verifica que tengas permisos de ubicación habilitados
- Usa HTTPS (no HTTP) en producción
- Algunos navegadores requieren confirmación manual

### "El CSV se ve mal en Excel"
**Solución**: 
- Abre Excel, ve a Datos > Obtener datos externos
- Selecciona el CSV descargado
- Elige "UTF-8" como codificación

---

## 📈 Mejoras Futuras

Puedes extender la app con:

1. **Backend Database**: Conectar a Firebase, PostgreSQL, MongoDB
2. **Mapas**: Integrar Google Maps / Leaflet
3. **Reportes**: Generar PDF con estadísticas
4. **Notificaciones Push**: Alertas de nuevos registros
5. **Autenticación**: Login para gestores de emergencia
6. **Histórico**: Guardar versiones antiguas de registros
7. **Sincronización P2P**: Compartir datos entre dispositivos locales

---

## 📞 Contacto y Soporte

- **Reporte de bugs**: Crea un issue en GitHub
- **Sugerencias**: Envía un email o abre una discusión
- **Licencia**: MIT (puedes usar libremente en proyectos comerciales)

---

## 📄 Licencia

Este proyecto está bajo licencia **MIT**. Puedes usarlo libremente en proyectos personales o comerciales.

```
MIT License

Copyright (c) 2024 Emergency System Contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software...
```

---

## 🙏 Agradecimientos

Construido con:
- **React 18** - UI Framework
- **Tailwind CSS** - Estilos
- **IndexedDB** - Base de datos local
- **Service Workers** - Funcionalidad offline

---

## 🚀 ¡Comienza Ahora!

```bash
# 1. Descargar o clonar
git clone <repo-url>

# 2. Entrar a la carpeta
cd emergency-pwa

# 3. Iniciar servidor local
python -m http.server 8000

# 4. Abrir en navegador
# http://localhost:8000
```

**¡La app está lista para usar!** 🎉

---

*Última actualización: Agosto 2024*  
*Versión: 1.0.0*  
*Estado: Producción*
