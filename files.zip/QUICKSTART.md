# ⚡ Guía de Inicio Rápido

## 🎯 En 2 minutos

### Paso 1: Ejecutar localmente
```bash
python -m http.server 8000
# O: http-server
# O: Abrir index.html directamente en navegador
```

### Paso 2: Abrir en navegador
```
http://localhost:8000
```

### Paso 3: ¡Usar!
- Haz clic en "REGISTRAR NUEVA PERSONA"
- Rellena el formulario
- Haz clic en "GUARDAR REGISTRO"
- Ver datos en la pestaña "VER DATOS"

---

## 📋 Checklist de Despliegue

### Antes de ir a Producción
- [ ] Probar en Chrome, Firefox, Safari, Edge
- [ ] Verificar funcionamiento offline (desconectar internet)
- [ ] Instalar como app en Android/iOS
- [ ] Probar geolocalización en dispositivo real
- [ ] Cambiar colores/nombre si es necesario
- [ ] Configurar backend si necesitas sincronización

### Despliegue a Producción (Pick One)
- [ ] **Vercel**: `vercel`
- [ ] **Netlify**: `netlify deploy --prod --dir=.`
- [ ] **GitHub Pages**: Push a repo
- [ ] **AWS S3**: `aws s3 sync . s3://bucket/`
- [ ] **Servidor propio**: Copiar archivos + HTTPS

---

## 🎮 Prueba Rápida sin Conexión

1. Abre la app en Chrome
2. Presiona F12 (DevTools)
3. Ve a Application → Service Workers
4. Checkea "Offline"
5. Recarga la página
6. ¡La app sigue funcionando!
7. Agrega un registro
8. Deschecka "Offline"
9. El registro se sincroniza (si backend está implementado)

---

## 📁 Archivos Explicados

| Archivo | Propósito |
|---------|-----------|
| `index.html` | App React completa + todo el código |
| `manifest.json` | Configuración PWA (instalable) |
| `sw.js` | Service Worker (offline + caché) |
| `README.md` | Documentación completa |
| `QUICKSTART.md` | Este archivo |

**¡Solo necesitas los primeros 3 archivos para que funcione!**

---

## 🎨 Personalización Rápida

### Cambiar Color Principal
En `index.html` y `manifest.json`:
```json
"theme_color": "#dc2626"  // Rojo actual
// Cambiar a:
"theme_color": "#2563eb"  // Azul
```

### Cambiar Nombre
En `manifest.json`:
```json
"name": "Mi Sistema de Emergencias Personalizado",
"short_name": "Emergencias Local"
```

### Cambiar Emojis
En `index.html`, busca y reemplaza:
```
🚨 → 🆘 (emoji alternativo)
```

---

## 🔧 Integración con Backend

Para sincronizar con un servidor, edita en `index.html`:

```javascript
// Busca esta función:
const syncToServer = async (registros) => {
  // Cambiar de:
  return Promise.resolve();
  
  // A:
  return fetch('https://tu-servidor.com/api/registros', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(registros)
  });
};
```

### Backend Esperado (ejemplo)
```
POST /api/registros
Content-Type: application/json

[
  {
    "nombre": "Juan",
    "edad": "35",
    "estado": "Verde",
    "ubicacion": "40.416775, -3.703790",
    "timestamp": "2024-08-17T14:30:23.451Z"
  }
]
```

---

## 📞 Problemas Comunes

| Problema | Solución |
|----------|----------|
| App no instala | Asegúrate de usar HTTPS en producción |
| Offline no funciona | Espera a que SW se registre, recarga F5 |
| No capture GPS | Verifica permisos de ubicación del navegador |
| Datos desaparecen | No limpies Storage de DevTools |
| CSV no abre bien | Abre con Excel > Datos > Importar |

---

## 🚀 Deploy Rápido en 1 Click

### Vercel (Recomendado)
```bash
npm i -g vercel
vercel
```
Tu app estará en: `https://nombre.vercel.app`

### Netlify
```bash
npm i -g netlify-cli
netlify deploy --prod --dir=.
```
Tu app estará en: `https://nombre.netlify.app`

---

## 📱 Instalar en Móvil

**Android:**
1. Abre Chrome
2. 3 puntos > Instalar app
3. ✅ Instalado

**iPhone:**
1. Abre Safari
2. Compartir > Agregar a Pantalla de Inicio
3. ✅ Instalado

---

## ✅ Testing Checklist

- [ ] Funciona sin internet
- [ ] Se pueden agregar registros
- [ ] Se pueden ver y buscar registros
- [ ] Se pueden eliminar registros
- [ ] CSV descarga correctamente
- [ ] JSON descarga correctamente
- [ ] GPS funciona (con permiso)
- [ ] Se instala como app
- [ ] Se ve bien en móvil
- [ ] Se ve bien en desktop

---

## 🎓 Próximos Pasos

1. **Personaliza**: Cambia colores y nombre
2. **Prueba**: Agrega registros de prueba
3. **Instala**: Como app en tu móvil
4. **Comparte**: URL con tu equipo
5. **Integra**: Backend si es necesario
6. **Desplega**: A producción

---

## 💡 Tips Pro

- Usa la app en modo pantalla completa (F11) durante emergencias
- Exporta registros regularmente como backup
- Instala en múltiples dispositivos para redundancia
- Usa GPS en coordenadas exactas vs direcciones
- Las notas son libres, úsalas para detalles médicos/críticos
- En offline, los datos están seguros localmente

---

**¡Listo para salvar vidas!** 🚨✨
